"""
    Course: ITAS 185 - Introduction to Programming
    Lab 1: Printing to the screen
    Description: This program simply prints things to the screen.
"""

print ("Information Technology & Applied Systems")
print ("900 Fifth St, Building 180")
print ("Nanaimo, BC, V9R 555")
