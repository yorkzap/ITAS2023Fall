"""
Course: ITAS 185 - Introduction to Programming
Test 1: Question 2
Description: This program takes in the cost, the number of people. It then calculates the amount with the tip included and gives cost per person.
"""

# Prompt the user to enter the total cost of a restaurant bill.
total_cost = float(input('Please enter the total value of your restaurant bill: $ '))

# Prompt the user to enter the number of people for the bill.
num_of_people = int(input('Enter the number of people for the bill: '))

# Calculate the total cost plus 20% tip.
total_cost_with_tip = total_cost * 1.2

# Calculate the cost per person and calculate the value as the total cost plus tip divided by the number of persons.
cost_per_head = round(total_cost_with_tip / num_of_people, 2)

# Display and format the result with cost, cost plus tip, the number of people and the cost per person
print(f"The cost of the meal was ${total_cost:.2f}. With tip that makes ${total_cost_with_tip:.2f}. For {num_of_people} people the cost per person was ${cost_per_head} each.")