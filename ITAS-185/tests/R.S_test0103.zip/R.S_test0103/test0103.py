"""
Course: ITAS 185 - Introduction to Programming
Test 1: Question 1
Description: This program calculates the volume of a cube given the length of one of it's sides.
"""

# Prompt the user to enter the length of the side of a square box. Read the value in as a float. Make sure the prompt is formatted nicely.
side_length = float(input("Please enter the length of the side of a square box: "))

# Volume of the cube with that length and calculate the volume USING EXPONENTS. The volume of the cube is the length times the length times the length (length times itself 3 times)
cube_volume = side_length ** 3

# Display the length of the side and the total volume. 
print(f"A square box with each side measuring {side_length:.2f} has a volume of {cube_volume} cubic units.")