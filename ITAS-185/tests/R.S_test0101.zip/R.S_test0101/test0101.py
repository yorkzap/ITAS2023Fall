"""
Course: ITAS 185 - Introduction to Programming
Test 1: Question 1
Description: This program multiplies a seed value by 2 times an integer entered by the user.
"""

# Initialize the seed value
seed = 10

# Prompt the user to input and converting it to integer
num_entered = int(input('Please enter an integer value '))

# Calculate the result by multiplying the seed by 2 times the entered number
seed_times_two_num = seed * 2 * num_entered

# Display the result
print(f"After multiplying the seed by 2 times {num_entered}, the result is {seed_times_two_num}.")